package battleship;

import java.util.Scanner;

public class BattleshipGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ocean ocean=new Ocean();
		
		
		ocean.placeAllShipsRandomly();
		ocean.print();
		int row;
		int column;
		int totalshot=0;
		int totalhit=0;
		int shipsSunk=0;
		Scanner scan=new Scanner(System.in);
		while(!ocean.isGameOver()) {
			
			System.out.println("Please enter row num (0-9)");
			row=scan.nextInt();
			System.out.println("Please enter column num (0-9)");
			column=scan.nextInt();
			
			//after user hit
			ocean.shootAt(row, column);
			totalshot=ocean.getShotsFired();
			totalhit=ocean.getHitCount();
			shipsSunk=ocean.getShipSunk();
			
			//print
			System.out.println("total shots= "+totalshot);
			System.out.println("total hits= "+totalhit);
			System.out.println("total sunk ships= "+shipsSunk);
			ocean.print();
		}
		

	}

}
