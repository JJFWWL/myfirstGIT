package battleship;

/**
 * @author hawkj
 *
 */
/**
 * @author hawkj
 *
 */
public abstract class Ship {
	/*
	 * the row number that contain the bow coord.
	 */
	private int bowRow;
	/*
	 * the column number that contain the bow coord.
	 */
	private int bowColumn;
	/*
	 * the number of ship length
	 */
	private int length;
	/*
	 * boolean to indicate whether the ship is horizontal
	 */
	private boolean horizontal;
	/*
	 * array of 4 booleans that indicate whether the part of ship has been hit
	 */
	private boolean[] hit;
	
	/**Ship constructor
	 * @param length
	 */
	public Ship(int length) {
		this.length = length;
		// initialize the hit array
		hit=new boolean[4];
	}
    
     // getters & setters
     
	/*
	 * return bowRow
	 */
	public int getBowRow() {
		return bowRow;
	}
    /*set bowrow
     * @param bowRow
     */
	public void setBowRow(int bowRow) {
		this.bowRow = bowRow;
	}
	
	/*
	 * return bowColumn
	 */

	public int getBowColumn() {
		return bowColumn;
	}
	
	/*set bowColumn
     * @param bowColumn
     */
	public void setBowColumn(int bowColumn) {
		this.bowColumn = bowColumn;
	}
	/*
	 * return horizontal
	 */
	public boolean isHorizontal() {
		return horizontal;
	}
	/*set horizontal
     * @param horizontal
     */
	public void setHorizontal(boolean horizontal) {
		this.horizontal = horizontal;
	}
	/*
	 * return length
	 */
	public int getLength() {
		return length;
	}
	/*
	 * return hit[]
	 */
	public boolean[] getHit() {
		return hit;
	}
	
	//abstract method
	/*
	 * force all ship to return their own shiptype
	 */
	public abstract String getShipType();
	
	//other method, non-abstract
	
	/**based on the given information, determine whether it is ok to place the ship
	 * @param row
	 * @param column
	 * @param horizontal
	 * @param ocean
	 * @return
	 */
	boolean okToPlaceShipAt (int row, int column, boolean horizontal, Ocean ocean) {
		boolean check=false;
		if (horizontal==false) {
			//condition when the ship is placed vertically
			if (row-this.length<0) {
				//ship length exceed the ocean boundary
				check=false;
			}
			else {
				//ship in ocean boundary, check occupy
				for(int i=0;i<this.length;i++) {
					if(ocean.isOccupied(row-i,column)) {
						check=false;
	
					}
					else {
						//condition the location is not occupied, but adjacent to a ship
						try {
							if(ocean.isOccupied(row-i+1,column)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {	
							if(ocean.isOccupied(row-i-1,column)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row-i,column+1)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row-i,column-1)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row-i+1,column+1)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row-i-1,column+1)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row-i+1,column-1)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row-i-1,column-1)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
							
							check=true;
						
						}
	
				  }
			}
			
		}
		
		else {
		//condition when the ship is placed horizontally
			if(column-this.length<0) {
				//ship length exceed the ocean boundary
				check=false;
			}
			
			else {
				//ship in ocean boundary, check occupy
				for(int i=0;i<this.length;i++) {
					if(ocean.isOccupied(row,column-i)) {
						check=false;
						break;
					}
					else {
						//condition the location is not occupied, but adjacent to a ship
						try {
							if(ocean.isOccupied(row+1,column-i)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {	
							if(ocean.isOccupied(row-1,column-i)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row,column+1-i)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row,column-1-i)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row+1,column+1-i)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row-1,column+1-i)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row+1,column-1-i)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
						try {
							if(ocean.isOccupied(row-1,column-1-i)) {
								check=false;
								break;
							}
						}
						catch (ArrayIndexOutOfBoundsException e) {}
							
							check=true;
						
					}
					
				}
			}
		}
		
		return check;
	}
	
	
	/**function to set the ocean shiparray with the given information
	 * @param row
	 * @param column
	 * @param horizontal
	 * @param ocean
	 */
	void placeShipAt(int row, int column, boolean horizontal, Ocean ocean) {
		//assign bow coordinate and direction boolean
		this.setBowRow(row);
		this.setBowColumn(column);
		this.setHorizontal(horizontal);
		//updated the ocean.ships array
		//condition when the ship is placed vertically
		if(horizontal==false) {
			for (int i=0;i<this.length;i++) {
				ocean.getShipArray()[row-i][column]=this;
			}
		}
		else {
			//condition when the ship is placed horizontally
			for (int i=0;i<this.length;i++) {
				ocean.getShipArray()[row][column-i]=this;
			}
		}
	}
	
	
	/**function to return true if the ship get hit, and update the hit array for the ship
	 * @param row
	 * @param column
	 * @return true if the ship is not sunk, otherwise false
	 */
	boolean shootAt(int row, int column) {
		if (this.isSunk()) {
			return false;
		}
		else {
			this.hit[this.bowRow-row+this.bowColumn-column]=true;
			return true;
			
		}
	}
	
	/**
	 * @return true if every part of the ship has been hit
	 */
	boolean isSunk() {
		boolean check=true;
		for(int i=0;i<this.length;i++) {
			if(this.hit[i]==false) {
				check=false;
				break;
			}
			else {
				check=true;
			}
		}
		
		return (check);
	}

	@Override
	public String toString() {
		if (this.isSunk()) {
			return "s";
		}
		else {
			
			return "o";
		}
	}

	
}
