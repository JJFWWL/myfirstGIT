package battleship;

/**
 * @author hawkj
 * represents Empty and extends Ship
 */
public class EmptySea extends Ship {
	
	static final int length=1;
	static final String name="empty";

	/**
	 * sub constructor to set the length 
	 */
	public EmptySea() {
		super(EmptySea.length);
		
	}

	/**
	 * override method to return name to the getshiptype
	 */
	@Override
	public String getShipType() {
		
		return (EmptySea.name);
	}

	/**
	 *override method to always return false
	 */
	@Override
	boolean isSunk() {
		return false;
	}

	/**
	 *override method to return "-" for empty ocean
	 */
	@Override
	public String toString() {
		//if get hit, return "-"
		if (this.getHit()[0]) {
		return "-";}
		else {
			return "."; // if not get hit, return "."
		}
	}
	
	
	

}
