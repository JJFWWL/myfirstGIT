package battleship;

/**
 * Represents a Cruiser as an subclass of Ship
 * @author tqiu592
 */
public class Cruiser extends Ship {

	/*
	 * static variables
	 */
	
	/** hard-coded length value for Cruiser */
	private static final int LEN_CRUISER = 3;
	
	/** hard-coded type value for Cruiser */
	private static final String TYP_CRUISER = "cruiser";
	
	/*
	 * constructors
	 */
	
	/**
	 * zero-argument constructor for Cruiser
	 */
	public Cruiser() {
		super(Cruiser.LEN_CRUISER);
	}
	
	/*
	 * inherited abstract methods
	 */
	
	/**
	 * Returns the type of the Cruiser instance
	 * @return the type of Ship as a String
	 */
	@Override
	public String getShipType() {
		return Cruiser.TYP_CRUISER;
	}

}
