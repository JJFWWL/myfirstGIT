package battleship;

import java.util.Random;

/**
 * Represents the 10x10 ocean for battleship game
 * @author tqiu592
 */
public class Ocean {
	
	/*
	 * static variables
	 */

	/** hard-coded size value for Ocean */
	static final int OCEAN_SIZE = 10;
	
	/** hard-coded total number of Battleship in the Ocean */
	private static final int NUM_BATTLESHIP = 1;

	/** hard-coded total number of Cruiser in the Ocean */
	private static final int NUM_CRUISER = 2;

	/** hard-coded total number of Destroyer in the Ocean */
	private static final int NUM_DESTROYER = 3;

	/** hard-coded total number of Submarine in the Ocean */
	private static final int NUM_SUBMARINE = 4;
	
	/*
	 * instance variables
	 */
	
	/** array representation of all Ship on the ocean, including EmptySea */
	private Ship[][] ships = new Ship[Ocean.OCEAN_SIZE][Ocean.OCEAN_SIZE];
	
	/** total number of shots fired by the user */
	private int shotsFired;
	
	/** number of times a shot hit a ship, every hit is counted */
	private int hitCount;
	
	/** number of ships sunk */
	private int shipsSunk;
	
	/** array representation of all shots fired on the ocean */
	private boolean[][] shots = new boolean[Ocean.OCEAN_SIZE][Ocean.OCEAN_SIZE];
	
	/** random number generator */
	private Random randGen = new Random();
	
	/*
	 * constructors
	 */
	
	/**
	 * Create an Ocean for Battleship game
	 */
	public Ocean() {
		
		//initialize the Ocean
		for (int i = 0; i < Ocean.OCEAN_SIZE; i++) {
			for (int j = 0; j < Ocean.OCEAN_SIZE; j++) {
				//Create new EmptySea on the Ocean
				Ship empty = new EmptySea();
				//Place EmptySea on the Ocean
				empty.placeShipAt(i, j, true, this);
				//Set all shots record to false
				this.shots[i][j] = false;
			}
		}
		
		//initialize properties for battle statistics
		this.shotsFired = 0;
		this.hitCount = 0;
		this.shipsSunk = 0;
		
	}
	
	/*
	 * getters and setters
	 */

	/**
	 * Returns the number of shots fired
	 * @return the shotsFired
	 */
	int getShotsFired() {
		return shotsFired;
	}

	/**
	 * Returns the number of hits recorded
	 * @return the hitCount
	 */
	int getHitCount() {
		return hitCount;
	}

	/**
	 * Returns the number of ships sunk
	 * @return the shipsSunk
	 */
	int getShipsSunk() {
		return shipsSunk;
	}
	
	/**
	 * Returns the 2-dimensional array of Ship
	 * @return the ships
	 */
	Ship[][] getShipArray() {
		return ships;
	}
	
	/*
	 * other methods
	 */
	
	/**
	 * Place all Ship randomly on the ocean, larger Ship before smaller Ship
	 */
	void placeAllShipsRandomly() {
		
		/*
		//for debugging
		for (int i = 0; i < Ocean.OCEAN_SIZE; i++) {
			for (int j = 0; j < Ocean.OCEAN_SIZE; j++) {
				//Set all shots record to true
				this.shots[i][j] = true;
			}
		}
		*/
		
		//Place Battleship
		for (int i = 0; i < Ocean.NUM_BATTLESHIP; i++) {
			Battleship newBattleship = new Battleship();
			this.placeShipRandomly(newBattleship);
		}

		//Place Cruiser
		for (int i = 0; i < Ocean.NUM_CRUISER; i++) {
			Cruiser newCruiser = new Cruiser();
			this.placeShipRandomly(newCruiser);
		}

		//Place Destroyer
		for (int i = 0; i < Ocean.NUM_DESTROYER; i++) {
			Destroyer newDestroyer = new Destroyer();
			this.placeShipRandomly(newDestroyer);
		}

		//Place Submarine
		for (int i = 0; i < Ocean.NUM_SUBMARINE; i++) {
			Submarine newSubmarine = new Submarine();
			this.placeShipRandomly(newSubmarine);
		}
		
		/*
		//for debugging
		for (int i = 0; i < Ocean.OCEAN_SIZE; i++) {
			for (int j = 0; j < Ocean.OCEAN_SIZE; j++) {
				//Set all shots record back to false
				this.shots[i][j] = false;
			}
		}
		*/
		
	}
	
	/**
	 * Find a random valid position on the ocean for the newShip and place it
	 * @param newShip Ship to be placed
	 */
	private void placeShipRandomly(Ship newShip) {
		
		//Generate a random position on the ocean
		int row = this.randGen.nextInt(Ocean.OCEAN_SIZE);
		int column = this.randGen.nextInt(Ocean.OCEAN_SIZE);
		boolean horizontal = this.randGen.nextBoolean();
		
		//Try placing the Ship at the randomly generated location
		while (!(newShip.okToPlaceShipAt(row, column, horizontal, this) && (!this.isOccupied(row, column)))) {
			//If the placement is invalid, generate a new random position
			row = this.randGen.nextInt(Ocean.OCEAN_SIZE);
			column = this.randGen.nextInt(Ocean.OCEAN_SIZE);
			horizontal = this.randGen.nextBoolean();
		}
		
		//If the placement is valid, place the ship at the position
		newShip.placeShipAt(row, column, horizontal, this);
		
		/*
		//for debugging
		this.print();
		*/
		
	}
	
	/**
	 * Check if the given location is occupied by a Ship
	 * @param row Row of given location
	 * @param column Column of given location
	 * @return a boolean indicating if the given location is occupied by a Ship
	 */
	boolean isOccupied(int row, int column) {
		return (this.ships[row][column].getShipType() != EmptySea.TYP_EMPTYSEA);
	}
	
	/**
	 * Shoot at the given location on the ocean, increments the shots fired
	 * If the given location has a Ship not sunk, increments the hit count, and return true
	 * Otherwise return false
	 * @param row Row of given location
	 * @param column Column of given location
	 * @return a boolean indicating if a Ship is hit at the given location
	 */
	boolean shootAt(int row, int column) {
		
		//Increment shots fired value for every user directed shot
		this.shotsFired++;
		
		//Record shots in array
		this.shots[row][column] = true;
		
		if (this.isOccupied(row, column)) {
			//Perform shooting to the Ship
			if (this.ships[row][column].shootAt(row, column)) {
				//Increment hit count value when the location is a floating real Ship
				this.hitCount++;
				//Increment ships sunk value after the Ship is hit
				if (this.ships[row][column].isSunk()) {
					this.shipsSunk++;
				}
				//Return true to indicate the shot hit a Ship
				return true;
			}
		}
		//Otherwise, return false to indicate the shot missed the Ship
		return false;
	}
	
	/**
	 * Check if all Ship have been sunk
	 * @return a boolean indicating if all Ship are sunk
	 */
	boolean isGameOver() {
		return this.getShipsSunk() == Ocean.NUM_BATTLESHIP + Ocean.NUM_CRUISER + Ocean.NUM_DESTROYER + Ocean.NUM_SUBMARINE;
	}
	
	/**
	 * Prints the Ocean
	 */
	void print() {
		//Loop through rows, start with header row
		for (int i = -1; i < Ocean.OCEAN_SIZE; i++) {
			//Loop through columns, start with index column
			for (int j = -1; j < Ocean.OCEAN_SIZE; j++) {
				if (i == -1) {
					if (j == -1) {
						//Top left corner, display blank
						System.out.print(" ");
					} else {
						//Header row, display column label
						System.out.print(j);
					}
				} else {
					if (j == -1) {
						//Index column, display row label
						System.out.print(i);
					} else {
						//Ocean map
						if (this.shots[i][j]) {
							//Display the ship status if location was shot, calling toString methods in Ship classes
							System.out.print(this.ships[i][j]);
						} else {
							//Covering up the location that was not shot yet
							System.out.print(".");
						}
					}
				}
				//Print a space before moving to next column
				System.out.print(" ");
			}
			//Print end of line after each row is completed
			System.out.println();
		}
	}
	
}
