package battleship;

/**
 * Represents a EmptySea as an subclass of Ship
 * @author tqiu592
 */
public class EmptySea extends Ship {

	/*
	 * static variables
	 */
	
	/** hard-coded length value for EmptySea */
	private static final int LEN_EMPTYSEA = 1;
	
	/** hard-coded type value for EmptySea */
	static final String TYP_EMPTYSEA = "empty";
	
	/*
	 * constructors
	 */
	
	/**
	 * zero-argument constructor for EmptySea
	 */
	public EmptySea() {
		super(EmptySea.LEN_EMPTYSEA);
	}
	
	/*
	 * inherited abstract methods
	 */
	
	/**
	 * Returns the type of the EmptySea instance
	 * @return the type of Ship as a String
	 */
	@Override
	public String getShipType() {
		return EmptySea.TYP_EMPTYSEA;
	}
	
	/*
	 * inherited other methods
	 */
	
	/**
	 * Returns false to indicate no Ship was hit
	 * @param row Row of given location
	 * @param column Column of given location
	 * @return false
	 */
	@Override
	boolean shootAt(int row, int column) {
		if (row == this.getBowRow() && column == this.getBowColumn()) {
			this.getHit()[0] = true;
		}
		return false;
	}
	
	/**
	 * Returns false to indicate no Ship is sunk
	 * @return false
	 */
	@Override
	boolean isSunk() {
		return false;
	}
	
	/**
	 * Returns a single-character String to use in the Ocean's print method
	 * Returns "-" to indicate a shot has been fired but nothing has been hit
	 */
	@Override
	public String toString() {
		return "-";
	}

}
