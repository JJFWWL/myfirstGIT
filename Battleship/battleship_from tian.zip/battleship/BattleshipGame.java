package battleship;

import java.util.Scanner;

/**
 * Controls the battleship game play
 * @author tqiu592
 */
public class BattleshipGame {
	
	/**
	 * Battleship game control main method
	 * @param args default main method arguments
	 */
	public static void main(String[] args) {
		
		//Launch text scanner for user inputs
		Scanner scanner = new Scanner(System.in);
		
		//Initialize game control parameters
		boolean playAgain = true;
		boolean askAgain = true;
		while (playAgain) {
			
			//Welcome message
	    	System.out.println();
	    	System.out.println("===============================");
	    	System.out.println("     Welcome to Battleship!    ");
	    	System.out.println("===============================");
			
	    	//Initialize the game
			Ocean ocean = new Ocean();
			ocean.placeAllShipsRandomly();
			
			//Loop for rounds of game
			while (!ocean.isGameOver()) {
				
				//Print the current map of ocean
				ocean.print();
				
		    	//Interact with user for input of shots
		    	System.out.println();
		    	System.out.println("Shoot at the coordinates: ");
		    	int i = -1;
		    	int j = -1;
		    	while (i < 0 || i >= Ocean.OCEAN_SIZE || j < 0 || j >= Ocean.OCEAN_SIZE) {
			    	System.out.print("Enter row: ");
			    	i = scanner.nextInt();
			    	System.out.print("Enter column: ");
			    	j = scanner.nextInt();
			    	System.out.println();
		    	}
		    	
		    	//Shoot at the coordinates user desire
		    	if (ocean.shootAt(i, j)) {
		    		System.out.println("You hit a ship: (" + i + ", " + j + ")");
		    	} else {
		    		System.out.println("You didn't hit a ship: (" + i + ", " + j + ")");
		    	}
		    	
		    	//Mark separation of rounds
		    	System.out.println("-------------------------------");
		    	
		    	/*
		    	//for debugging
		    	System.out.println("You fired " + ocean.getShotsFired() + " missiles.");
		    	System.out.println(ocean.getHitCount() + " shots hit a ship.");
		    	System.out.println(ocean.getShipsSunk() + " ships have sunk.");
		    	System.out.println("-------------------------------");
		    	*/
			}
			
			//Game over messages
	    	System.out.println("===============================");
	    	System.out.println("           Game Over!          ");
	    	System.out.println("-------------------------------");
	    	//Print game statistics
	    	System.out.println("You fired " + ocean.getShotsFired() + " missles.");
	    	System.out.println(ocean.getHitCount() + " shots hit a ship.");
	    	System.out.println(ocean.getShipsSunk() + " ships have sunk.");
	    	System.out.println("-------------------------------");
	    	//Print final results
	    	ocean.print();
	    	System.out.println("-------------------------------");
	    	//Print evaluation message based on total shots fired
	    	if (ocean.getShotsFired() <= 45) {
	    		System.out.println("Unbelievable!!!!!!");
	    	} else if (ocean.getShotsFired() <= 55) {
	    		System.out.println("Excellent!!!!");
	    	} else if (ocean.getShotsFired() <= 65) {
	    		System.out.println("Well Done!!!");
	    	} else if (ocean.getShotsFired() <= 75) {
	    		System.out.println("Good Job!!");
	    	} else if (ocean.getShotsFired() <= 85) {
	    		System.out.println("Good Game!");
	    	} else {
	    		System.out.println("Mission Accomplished.");
	    	}
	    	System.out.println("===============================");
	    	System.out.println();
	    	
	    	//Get user input whether to play again
			askAgain = true;
			while (askAgain) {
				System.out.println("Do you want to play again? [Y/N]");
				String replay = scanner.next();
				if (replay.charAt(0) == 'N' || replay.charAt(0) == 'n') {
					playAgain = false;
					askAgain = false;
					break;
				} else if (replay.charAt(0) == 'Y' || replay.charAt(0) == 'y') {
					playAgain = true;
					askAgain = false;
					break;
				} else {
					askAgain = true;
				}
			}
	    	
		}
		
		//Close text scanner
		scanner.close();
    	
	}

}
