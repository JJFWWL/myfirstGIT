package battleship;

/**
 * Represents a Battleship as an subclass of Ship
 * @author tqiu592
 */
public class Battleship extends Ship {

	/*
	 * static variables
	 */
	
	/** hard-coded length value for Battleship */
	private static final int LEN_BATTLESHIP = 4;
	
	/** hard-coded type value for Battleship */
	private static final String TYP_BATTLESHIP = "battleship";
	
	/*
	 * constructors
	 */
	
	/**
	 * zero-argument constructor for Battleship
	 */
	public Battleship() {
		super(Battleship.LEN_BATTLESHIP);
	}
	
	/*
	 * inherited abstract methods
	 */
	
	/**
	 * Returns the type of the Battleship instance
	 * @return the type of Ship as a String
	 */
	@Override
	public String getShipType() {
		return Battleship.TYP_BATTLESHIP;
	}

}
