package battleship;

/**
 * Represents a Destroyer as an subclass of Ship
 * @author tqiu592
 */
public class Destroyer extends Ship {

	/*
	 * static variables
	 */
	
	/** hard-coded length value for Destroyer */
	private static final int LEN_DESTROYER = 2;
	
	/** hard-coded type value for Destroyer */
	private static final String TYP_DESTROYER = "destroyer";
	
	/*
	 * constructors
	 */
	
	/**
	 * zero-argument constructor for Destroyer
	 */
	public Destroyer() {
		super(Destroyer.LEN_DESTROYER);
	}
	
	/*
	 * inherited abstract methods
	 */
	
	/**
	 * Returns the type of the Destroyer instance
	 * @return the type of Ship as a String
	 */
	@Override
	public String getShipType() {
		return Destroyer.TYP_DESTROYER;
	}

}
