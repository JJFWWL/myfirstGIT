package battleship;

/**
 * Represents a Submarine as an subclass of Ship
 * @author tqiu592
 */
public class Submarine extends Ship {

	/*
	 * static variables
	 */
	
	/** hard-coded length value for Submarine */
	private static final int LEN_SUBMARINE = 1;
	
	/** hard-coded type value for Submarine */
	private static final String TYP_SUBMARINE = "submarine";
	
	/*
	 * constructors
	 */
	
	/**
	 * zero-argument constructor for Submarine
	 */
	public Submarine() {
		super(Submarine.LEN_SUBMARINE);
	}
	
	/*
	 * inherited abstract methods
	 */
	
	/**
	 * Returns the type of the Submarine instance
	 * @return the type of Ship as a String
	 */
	@Override
	public String getShipType() {
		return Submarine.TYP_SUBMARINE;
	}

}
