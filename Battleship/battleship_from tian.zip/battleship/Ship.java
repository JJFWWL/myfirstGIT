package battleship;

/**
 * Represents all types of Ship and describes the common characteristics
 * @author tqiu592
 */
public abstract class Ship {
	
	/*
	 * instance variables
	 */
	
	/** the row that contains the bow (front part of the ship) */
	private int bowRow;
	
	/** the column that contains the bow (front part of the ship) */
	private int bowColumn;
	
	/** the length of the ship */
	private int length;
	
	/** a boolean represents whether the ship is placed horizontally or vertically */
	private boolean horizontal;
	
	/** an array of 4 booleans that indicate whether a part of the ship has been hit or not */
	private boolean[] hit;
	
	/*
	 * constructors
	 */
	
	/**
	 * the default constructor for the Ship, sets the length property of the Ship and initializes the hit array property
	 * @param length Length of Ship
	 */
	public Ship(int length) {
		this.length = length;
		this.hit = new boolean[4]; //hard-coded array length, not subject to ship length
		for (int i = 0; i < length; i++) {
			this.hit[i] = false;
		}
	}
	
	/*
	 * getters and setters
	 */
	
	/**
	 * Gets the row corresponding to the position of the bow
	 * @return the bowRow
	 */
	public int getBowRow() {
		return bowRow;
	}
	
	/**
	 * Sets the row corresponding to the position of the bow
	 * @param bowRow the bowRow to set
	 */
	public void setBowRow(int bowRow) {
		this.bowRow = bowRow;
	}
	
	/**
	 * Gets the column corresponding to the position of the bow
	 * @return the bowColumn
	 */
	public int getBowColumn() {
		return bowColumn;
	}
	
	/**
	 * Sets the column corresponding to the position of the bow
	 * @param bowColumn the bowColumn to set
	 */
	public void setBowColumn(int bowColumn) {
		this.bowColumn = bowColumn;
	}
	
	/**
	 * Gets the length of the Ship
	 * @return the length
	 */
	public int getLength() {
		return length;
	}
	
	/**
	 * Returns whether the ship is horizontal or vertical
	 * @return the boolean value indicates horizontal or not
	 */
	public boolean isHorizontal() {
		return horizontal;
	}
	
	/**
	 * Sets the boolean value indicates horizontal or not
	 * @param horizontal the boolean value to set
	 */
	public void setHorizontal(boolean horizontal) {
		this.horizontal = horizontal;
	}
	
	/**
	 * Returns the hit array indicating the parts of the Ship is hit or not
	 * @return the hit boolean array
	 */
	public boolean[] getHit() {
		return hit;
	}
	
	/*
	 * abstract methods
	 */
	
	/**
	 * Returns the type of the Ship instance
	 * @return the type of Ship as a String
	 */
	public abstract String getShipType();
	
	/*
	 * other methods
	 */
	
	/**
	 * Check if the placement of Ship is valid at given row and column of given ocean with given horizontal/vertical orientation
	 * horizontal ships face East (bow at right end) and vertical ships face South (bow at bottom end)
	 * @param row Row of given location
	 * @param column Column of given location
	 * @param horizontal indicator whether the Ship to be placed horizontally or vertically
	 * @param ocean Ocean to place Ship
	 * @return a boolean value if placement is valid
	 */
	boolean okToPlaceShipAt(int row, int column, boolean horizontal, Ocean ocean) {
		if (row >= 0 && row < Ocean.OCEAN_SIZE && column >= 0 && column < Ocean.OCEAN_SIZE) {
			if (horizontal) {
				//Loop through rows: one row above, row of ship (bow), and one row below
				for (int i = row - 1; i <= row + 1; i++) {
					//Loop through columns: one column to the right of bow, columns of ship, one column to the right of ship
					for (int j = column + 1; j >= column - this.getLength(); j--) {
						if (i >= 0 && i < Ocean.OCEAN_SIZE && j >= 0 && j < Ocean.OCEAN_SIZE) {
							//Check valid locations only
							if (ocean.isOccupied(i, j)) {
								//Whenever found an occupied location around the ship, return false
								return false;
							}
						} else {
							//Check if the ship is too long to fit within the map
							if (column < this.getLength() - 1) {
								//Whenever the ship going out of map, return false
								return false;
							}
						}
					}
				}
			} else {
				//Loop through columns: one column to the left, column of ship (bow), and one column to the right
				for (int j = column - 1; j <= column + 1; j++) {
					//Loop through rows: one row above the ship, rows of ship, and one row below the bow
					for (int i = row + 1; i >= row - this.getLength(); i--) {
						if (i >= 0 && i < Ocean.OCEAN_SIZE && j >= 0 && j < Ocean.OCEAN_SIZE) {
							//Check valid locations only
							if (ocean.getShipArray()[i][j].getShipType() != EmptySea.TYP_EMPTYSEA) {
								//Whenever found an occupied location around the ship, return false
								return false;
							}
						} else {
							//Check if the ship is too long to fit within the map
							if (row < this.getLength() - 1) {
								//Whenever the ship going out of map, return false
								return false;
							}
						}
					}
				}
			}
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Places the Ship at given row and column of given ocean with given horizontal/vertical orientation
	 * horizontal ships face East (bow at right end) and vertical ships face South (bow at bottom end)
	 * @param row Row of given location
	 * @param column Column of given location
	 * @param horizontal indicator whether the Ship to be placed horizontally or vertically
	 * @param ocean Ocean to place Ship
	 */
	void placeShipAt(int row, int column, boolean horizontal, Ocean ocean) {
		//Set the instance variables with given parameters
		this.setBowRow(row);
		this.setBowColumn(column);
		this.setHorizontal(horizontal);
		//Link the ship to the corresponding locations on the ocean map
		if (horizontal) {
			//Horizontal ship is placed facing East, bow at right end
			int i = row;
			for (int j = column; j > column - this.getLength(); j--) {
				ocean.getShipArray()[i][j] = this;
			}
		} else {
			//Vertical ship is placed facing South, bow at bottom end
			int j = column;
			for (int i = row; i > row - this.getLength(); i--) {
				ocean.getShipArray()[i][j] = this;
			}
		}
	}
	
	/**
	 * Returns if a part of the Ship is hit when shooting at the given row and column of the ocean
	 * @param row Row of given location
	 * @param column Column of given location
	 * @return a boolean value if the shot has hit a part of the Ship
	 */
	boolean shootAt(int row, int column) {
		if (this.isSunk()) {
			//When the ship is sunk, the shot is missed
			return false;
		} else {
			try {
				if (this.isHorizontal()) {
					if (row == this.bowRow) {
						//try to update the hit array, index out of bound exception to be caught when arisen
						this.hit[this.bowColumn - column] = true;
						return true;
					} else {
						//The horizontal ship won't be hit for all rows but bow row
						return false;
					}
				} else {
					if (column == this.bowColumn) {
						//try to update the hit array, index out of bound exception to be caught when arisen
						this.hit[this.bowRow - row] = true;
						return true;
					} else {
						//The vertical ship won't be hit for all columns but bow column
						return false;
					}
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				//Exception will arise only when the shootAt method is called outside of the game directly
				//The index out of bound exception is driven by the call of hit array
				return false;
			}
		}
	}
	
	/**
	 * Returns if the Ship is sunk, a.k.a. all parts of the Ship has been hit
	 * @return a boolean value if the Ship is sunk
	 */
	boolean isSunk() {
		for(int i = 0; i < this.length; i++) {
			if (!this.hit[i]) {
				//If any part of the Ship is not hit yet, the ship is not sunk
				return false;
			}
		}
		//The ship is sunk after all parts of the Ship is hit
		return true;
	}
	
	/**
	 * Returns a single-character String to use in the Ocean's print method
	 * Returns "s" if the ship is sunk, and "x" if it is not sunk
	 */
	@Override
	public String toString() {
		if (this.isSunk()) {
			return "s";
		} else {
			return "x";
		}
	}
	
}
